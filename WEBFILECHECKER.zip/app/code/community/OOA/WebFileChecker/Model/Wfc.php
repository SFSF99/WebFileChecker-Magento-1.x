<?php
/*
 *
 * @category   OOA
 * @package    OOA_WebFileChecker
 * @copyright  Open Software (2016)
 *
 */
class OOA_WebFileChecker_Model_Wfc extends Mage_Core_Model_Abstract {

	public $chgdir;
	public $email_subject1;
	public $email_subject2;
	public $email_address_list;
	public $modifications_list;
	public $modifications_email;
	public $file_types;
	public $log_size;
	public $title;

	public $handle_r;
	public $handle_m;

	public $ooa_webfilechecker_modifications_log;
	public $ooa_webfilechecker_modifications_log_name;
	public $ooa_webfilechecker_reference_log;
	public $ooa_webfilechecker_reference_conf_log;

	protected function _construct() {
	    $this->_init('webfilechecker/wfc');
	}

	public function CronjobCode() { // called online (/webfilechecker) or by cron schedule

		/* ini_set("memory_limit","1024M"); */
		/* ini_set("max_execution_time","1800");*/

		umask(0);
		Mage::app()->setCurrentStore(Mage_Core_Model_App::ADMIN_STORE_ID);

		$this->chgdir = dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))); // catalog directory magento

		chdir($this->chgdir);

		$this->email_subject1 = Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_EMAIL_SUBJECT1');
		$this->email_subject2 = Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_EMAIL_SUBJECT2');
		$this->email_subject3 = Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_EMAIL_SUBJECT3');
		$ea = Mage::getStoreConfig('webfilechecker/options/MODULE_OOA_WEBFILECHECKER_EMAIL_ADDRESS');
		if ($ea == '') {
			$ea = Mage::getStoreConfig('trans_email/ident_general/email');
		}
		$this->email_address_list = $ea;
		$this->file_types = Mage::getStoreConfig('webfilechecker/options/MODULE_OOA_WEBFILECHECKER_FILE_TYPES');
		$this->log_size = (float)Mage::getStoreConfig('webfilechecker/options/MODULE_OOA_WEBFILECHECKER_LOG_SIZE');

		$this->ooa_webfilechecker_modifications_log = $this->chgdir . "/var/wfc/ooa_wfc_mod.log";
		$this->ooa_webfilechecker_modifications_log_name = $this->chgdir . "/var/wfc/ooa_wfc_mod";
		$this->ooa_webfilechecker_reference_log = $this->chgdir . "/var/wfc/ooa_wfc_ref.log";
		$this->ooa_webfilechecker_reference_conf_log = $this->chgdir . "/var/wfc/ooa_wfc_ref_conf.log";

		$this->Scan();

		try {
			$addresses = preg_split('/[,;]/', $this->email_address_list);
			for ($i=0; $i<sizeof($addresses); $i+=1) {
				$mail = new Zend_Mail();
				$mail->setFrom("", "");
				$mail->addTo($addresses[$i], "");
				if ($this->modifications_list == '') {
				    $mail->setSubject($this->email_subject1 . "(" . $this->title . ")");
				    $mail->setBodyHtml("");
				} elseif ($this->modifications_list == 'first_run') {
					$mail->setSubject($this->email_subject3 . "(" . $this->title . ")");
					$mail->setBodyHtml("");
				} else {
					$mail->setSubject($this->email_subject2 . "(" . $this->title . ")");
					$mail->setBodyHtml($this->modifications_email);
					$at = new Zend_Mime_Part($this->modifications_list);

					$at->type = "text/csv";
					$at->disposition = Zend_Mime::DISPOSITION_INLINE;
					$at->encoding = Zend_Mime::ENCODING_8BIT;
					$at->filename = "modifications_list.txt";
					$mail->addAttachment($at);
				}
				$mail->send();
			}
		} catch(Exception $e) {
			throw $e;
		}

		// free memory
		unset($this->modifications_list);
		unset($this->modifications_email);
	}

	public function Scan() {

		$file_types_array = explode(",", preg_replace("/\s+/", "", $this->file_types));

		$ref_array = array();
		$dir_array = array();
		$files_array = array();
		$files_date_array = array();

		$first_run = false;

		try {
			if (!file_exists($this->ooa_webfilechecker_modifications_log)) {
				$first_run = true;
			}
			if (file_exists($this->ooa_webfilechecker_modifications_log) and ((filesize($this->ooa_webfilechecker_modifications_log) / (1024*1024)) >= $this->log_size)) {
				rename($this->ooa_webfilechecker_modifications_log, $this->ooa_webfilechecker_modifications_log_name . "_" . date("Ymd") . "_" . date("His") . ".log");
			}

			$this->handle_r = fopen($this->ooa_webfilechecker_reference_log, "a"); // create file first time
			fclose($this->handle_r);
			$this->handle_m = fopen($this->ooa_webfilechecker_modifications_log, "a");
			$this->handle_r = fopen($this->ooa_webfilechecker_reference_log, "r");
			$dir_handle = opendir($this->chgdir);
		} catch(Exception $e) {
			throw $e;
		}

		$dir_string = $this->chgdir;
		while (($entry = readdir($dir_handle)) !== false) {
			if ($entry != '.' and $entry != '..') {
				if (is_dir($dir_string . "/" . $entry)) {
					if (!in_array($dir_string . "/" . $entry, $dir_array)) {
						array_push($dir_array, $dir_string . "/" . $entry);
					}
				} else {
					if (in_array(substr(strrchr($entry, '.'), 1), $file_types_array, true) == true){
						if (!in_array($dir_string . "/" . $entry, $files_array)) {
							array_push($files_array, $dir_string . "/" . $entry);
							array_push($files_date_array, " ( " . date("Y-m-d H:i:s", filemtime($dir_string . "/" . $entry)) . " )");
						}
					}
				}
			}
		}
		closedir($dir_handle);

		if (count($dir_array) == 1 and (!isset($dir_array[0]) or $dir_array[0] == '')) {
			$dir_array = array();
		}
		if (count($files_array) == 1 and (!isset($files_array[0]) or $files_array[0] == '')) {
			$files_array = array();
		}

		for ($i=0; $i<count($dir_array); $i++) {
			try {
				$dir_handle = opendir($dir_array[$i]);
			} catch(Exception $e) {
				throw $e;
			}

			$dir_string = $dir_array[$i];
			while (($entry = readdir($dir_handle)) !== false) {
				if ($entry != '.' and $entry != '..') {
					if (is_dir($dir_string . "/" . $entry)) {
						if (!in_array($dir_string . "/" . $entry, $dir_array)) {
							array_push($dir_array, $dir_string . "/" . $entry);
						}
					} else {
						if (in_array(substr(strrchr($entry, '.'), 1), $file_types_array, true) == true){
							if (!in_array($dir_string . "/" . $entry, $files_array)){
								array_push($files_array, $dir_string . "/" . $entry);
								array_push($files_date_array, " (" . date("Y-m-d H:i:s", filemtime($dir_string . "/" . $entry)) . ")");
							}
						}
					}
				}
			}
			closedir($dir_handle);
		}

		if (count($dir_array) == 1 and (!isset($dir_array[0]) or $dir_array[0] == '')) {
			$dir_array = array();
		}
		if (count($files_array) == 1 and (!isset($files_array[0]) or $files_array[0] == '')) {
			$files_array = array();
		}

		for ($i=0; $i<count($files_array); $i++) {
			array_push($ref_array, md5_file($files_array[$i]));
		}

		$added_array = array();
		$removed_array = array();
		$changed_array = array();
		$files_array2 = array();
		$ref_array2 = array();

		$i = 0;
		while (!feof($this->handle_r)) {
			$files_array2[$i] = trim(fgets($this->handle_r));
			$ref_array2[$i] = trim(fgets($this->handle_r));
			$i++;
		}
		fclose($this->handle_r);

		if (count($files_array2) == 1 and (!isset($files_array2[0]) or $files_array2[0] == '')) {
			$files_array2 = array();
		}
		if (count($ref_array2) == 1 and (!isset($ref_array2[0]) or $ref_array2[0] == '')) {
			$ref_array2 = array();
		}

		if (count($files_array) > count($files_array2)) {
			do {
				array_push($files_array2, "");
				array_push($ref_array2, "");
			} while (count($files_array) > count($files_array2));
		} elseif (count($files_array2) > count($files_array)) {
			do {
				array_push($files_array, "");
				array_push($ref_array, "");
			} while (count($files_array2) > count($files_array));
		}

		for ($i=0; $i<count($files_array); $i++) {
			if ($files_array[$i] != '') {
				if (!in_array($files_array[$i], $files_array2)) {
					array_push($added_array, $files_array[$i] . $files_date_array[$i]);
				}
			}
			if ($files_array2[$i] != '') {
				if (!in_array($files_array2[$i], $files_array)) {
					array_push($removed_array, $files_array2[$i] . " (" . date("Y-m-d H:i:s") . ")");
				}
			}
			if ($ref_array[$i] != '') {
				$indexs = array_search($files_array[$i], $files_array2);
				if ($indexs != false) {
				    if ($ref_array[$i] != $ref_array2[$indexs]) {
				    	array_push($changed_array, $files_array[$i] . $files_date_array[$i]);
				    }
				}
			}
		}

		if (count($added_array) == 1 and (!isset($added_array[0]) or $added_array[0] == '')) {
			$added_array = array();
		}
		if (count($removed_array) == 1 and (!isset($removed_array[0]) or $removed_array[0] == '')) {
			$removed_array = array();
		}
		if (count($changed_array) == 1 and (!isset($changed_array[0]) or $changed_array[0] == '')) {
			$changed_array = array();
		}

		$this->title = Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_TITLE') . " " . date("d F Y") . " " . date("H:i:s");

		$this->modifications_list = $this->title . "\r\n\r\n";
		$this->modifications_email = $this->title . "<br><br>";
		$mods = 0;
		if (count($added_array) > 0) {
			$mods++;
			$this->modifications_list .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_ADDED_FILES') . ":" . "\r\n" . implode("\r\n", $added_array) . "\r\n\r\n";
			$this->modifications_email .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_ADDED_FILES') . ":" . "<br>" . implode("<br>", $added_array) . "<br><br>";
		}
		if (count($removed_array) > 0) {
			$mods++;
			$this->modifications_list .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_REMOVED_FILES') . ":" . "\r\n" . implode("\r\n", $removed_array) . "\r\n\r\n";
			$this->modifications_email .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_REMOVED_FILES') . ":" . "<br>" . implode("<br>", $removed_array) . "<br><br>";
		}
		if (count($changed_array) > 0) {
			$mods++;
			$this->modifications_list .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_CHANGED_FILES') . ":" . "\r\n" . implode("\r\n", $changed_array) . "\r\n\r\n";
			$this->modifications_email .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_CHANGED_FILES') . ":" . "<br>" . implode("<br>", $changed_array) . "<br><br>";
		}

		$ref_list_new = "";
		for ($i=0; $i<count($files_array); $i++) {
			$ref_list_new .= $files_array[$i] . "\r\n" . $ref_array[$i] . "\r\n";
		}
		try {
			$this->handle_r = fopen($this->ooa_webfilechecker_reference_log, "w");
			fwrite($this->handle_r, trim($ref_list_new));
			fclose($this->handle_r);
		} catch(Exception $e) {
			throw $e;
		}

		// free memory
		unset($ref_array) ;
		unset($dir_array);
		unset($files_array);
		unset($files_date_array);
		unset($added_array);
		unset($removed_array);
		unset($changed_array);
		unset($files_array2);
		unset($ref_array2);
		unset($ref_list_new);

		// check configuration

		$conf_p_array = array();
		$conf_v_array = array();
		$ref_array = array();

		try {
			$this->handle_r = fopen($this->ooa_webfilechecker_reference_conf_log, "a"); // create file first time
			fclose($this->handle_r);
			$this->handle_m = fopen($this->ooa_webfilechecker_modifications_log, "a");
			$this->handle_r = fopen($this->ooa_webfilechecker_reference_conf_log, "r");
		} catch(Exception $e) {
			throw $e;
		}

		$resource = Mage::getSingleton('core/resource');
		$readConnection = $resource->getConnection('core_read');
		$table = $resource->getTableName('core_config_data');
		$query = "select * from " . $table . " order by scope, scope_id, path";
		$config = $readConnection->query($query);
		$i = 0;
		while ($row = $config->fetch()) {
			$conf_p_array[$i] = $row['scope'] . "\t" . $row['scope_id'] . "\t" . $row['path'];
			$conf_v_array[$i] = $row['value'];
			$ref_array[$i] = md5($row['scope'] . "\t" . $row['scope_id'] . "\t" . $row['path'] . "\t" . $row['value']);
			$i++;
		}

		$added_array = array();
		$removed_array = array();
		$changed_array = array();
		$conf_p_array2 = array();
		$ref_array2 = array();

		$i = 0;
		while (!feof($this->handle_r)) {
			$ref = preg_split('/\t/', trim(fgets($this->handle_r)));
			if (sizeof($ref) < 3) {
				continue;
			}
			$conf_p_array2[$i] = $ref[0] . "\t" . $ref[1] . "\t" . $ref[2];
			$ref_array2[$i] = trim(fgets($this->handle_r));
			$i++;
		}
		fclose($this->handle_r);

		if (count($conf_p_array) > count($conf_p_array2)) {
			do {
				array_push($conf_p_array2, "");
				array_push($ref_array2, "");
			} while (count($conf_p_array) > count($conf_p_array2));
		} elseif (count($conf_p_array2) > count($conf_p_array)) {
			do {
				array_push($conf_p_array, "");
				array_push($ref_array, "");
			} while (count($conf_p_array2) > count($conf_p_array));
		}

		for ($i=0; $i<count($conf_p_array); $i++) {
			if ($conf_p_array[$i] != '') {
				if (!in_array($conf_p_array[$i], $conf_p_array2)) {
					array_push($added_array, $conf_p_array[$i] . "\t" . $conf_v_array[$i]);
				}
			}
			if ($conf_p_array2[$i] != '') {
				if (!in_array($conf_p_array2[$i], $conf_p_array)) {
					array_push($removed_array, $conf_p_array2[$i]);
				}
			}
			if ($ref_array[$i] != '') {
				$indexs = array_search($conf_p_array[$i], $conf_p_array2);
				if ($indexs != false) {
					if ($ref_array[$i] != $ref_array2[$indexs]) {
						array_push($changed_array, $conf_p_array[$i] . "\t" . $conf_v_array[$i]);
					}
				}
			}
		}

		if (count($added_array) == 1 and (!isset($added_array[0]) or $added_array[0] == '')) {
			$added_array = array();
		}
		if (count($removed_array) == 1 and (!isset($removed_array[0]) or $removed_array[0] == '')) {
			$removed_array = array();
		}
		if (count($changed_array) == 1 and (!isset($changed_array[0]) or $changed_array[0] == '')) {
			$changed_array = array();
		}

		if (count($added_array) > 0) {
			$mods++;
			$this->modifications_list .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_ADDED_CONF') . ":" . "\r\n" . implode("\r\n", $added_array) . "\r\n\r\n";
			$this->modifications_email .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_ADDED_CONF') . ":" . "<br>" . implode("<br>", $added_array) . "<br><br>";
		}
		if (count($removed_array) > 0) {
			$mods++;
			$this->modifications_list .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_REMOVED_CONF') . ":" . "\r\n" . implode("\r\n", $removed_array) . "\r\n\r\n";
			$this->modifications_email .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_REMOVED_CONF') . ":" . "<br>" . implode("<br>", $removed_array) . "<br><br>";
		}
		if (count($changed_array) > 0) {
			$mods++;
			$this->modifications_list .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_CHANGED_CONF') . ":" . "\r\n" . implode("\r\n", $changed_array) . "\r\n\r\n";
			$this->modifications_email .= Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_CHANGED_CONF') . ":" . "<br>" . implode("<br>", $changed_array) . "<br><br>";
		}

		$ref_list_new = "";
		for ($i=0; $i<count($conf_p_array); $i++) {
			$ref_list_new .= $conf_p_array[$i] . "\r\n" . $ref_array[$i] . "\r\n";
		}
		try {
			$this->handle_r = fopen($this->ooa_webfilechecker_reference_conf_log, "w");
			fwrite($this->handle_r, trim($ref_list_new));
			fclose($this->handle_r);
		} catch(Exception $e) {
			throw $e;
		}

		if ($mods == 0) {
			$this->modifications_list = "";
			$this->modifications_email = "";
		}

		try {
			fwrite($this->handle_m, $this->modifications_list);
			fclose($this->handle_m);
		} catch(Exception $e) {
			throw $e;
		}

		// free memory
		unset($ref_array) ;
		unset($conf_p_array);
		unset($conf_v_array);
		unset($added_array);
		unset($removed_array);
		unset($changed_array);
		unset($conf_p_array2);
		unset($conf_v_array2);
		unset($ref_array2);
		unset($ref_list_new);

		if ($first_run) {
			$this->modifications_list = "first_run";
		}
	}

}
?>