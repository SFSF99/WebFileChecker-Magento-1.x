<?php
/*
 *
 * @category   OOA
 * @package    OOA_WebFileChecker
 * @copyright  Open Software (2016)
 *
 */
class OOA_WebFileChecker_Block_View extends Mage_Adminhtml_Block_System_Config_Form_Field
{

    protected function _toHtml()
    {
    	$file = dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))) . "/var/wfc/ooa_wfc_mod.log";

    	$str = file_get_contents($file);

    	$html = str_replace("\r\n", "<br>", $str);

        return $html;
    }
}
?>