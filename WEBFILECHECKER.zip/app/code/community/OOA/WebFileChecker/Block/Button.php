<?php
/*
 *
 * @category   OOA
 * @package    OOA_WebFileChecker
 * @copyright  Open Software (2016)
 *
 */
class OOA_WebFileChecker_Block_Button extends Mage_Adminhtml_Block_System_Config_Form_Field
{

    protected function _getElementHtml(Varien_Data_Form_Element_Abstract $element)
    {
        $this->setElement($element);

        //$url = $this->getUrl(Mage::getConfig()->getNode('admin/routers/adminhtml/args/frontName') . '/webfilechecker/view');
        $url = $this->getUrl('/webfilechecker/view');

        $html = $this->getLayout()->createBlock('adminhtml/widget_button')
                    ->setType('button')
                    ->setClass('scalable')
                    ->setLabel(Mage::helper('webfilechecker')->__('MODULE_OOA_WEBFILECHECKER_VIEW'))
                    ->setOnClick("setLocation('$url')")
                    //->setOnClick("window.open('$url')")
                    ->toHtml();

        return $html;
    }
}
?>