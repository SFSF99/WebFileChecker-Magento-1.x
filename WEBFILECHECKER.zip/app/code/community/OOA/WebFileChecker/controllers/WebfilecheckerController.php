<?php
/*
 *
 * @category   OOA
 * @package    OOA_WebFileChecker
 * @copyright  Open Software (2016)
 *
 */
class OOA_WebFileChecker_WebfilecheckerController extends Mage_Adminhtml_Controller_Action
{

    /*
     * this method privides default action.
     */
    public function indexAction()
    {
        $obj = Mage::getModel('webfilechecker/wfc');
        $obj->CronjobCode();
    }

    public function viewAction()
    {
    	$this->loadLayout();
    	$this->_addContent($this->getLayout()->createBlock('webfilechecker/view'))
    	->renderLayout();
    }

}
?>